import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const ProductDetails = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch product details by ID
    fetch(`https://dummyjson.com/products/${id}`)
      .then((res) => res.json())
      .then((data) => {
        setProduct(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Error fetching product details:', err);
        setLoading(false);
      });
  }, [id]);

  const handleBackToCategory = () => {
    // Navigate to the category of the product
    if (product && product.category) {
      navigate(`/category/${product.category}`);
    } else {
      navigate('/'); // Navigate to home if no category found
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (!product) {
    return <div>Product not found.</div>;
  }

  return (
    <div style={{ padding: '20px' }}>
      <h2>{product.title}</h2>
      {/* Product Image with reduced size */}
      <img
        src={product.thumbnail}
        alt={product.title}
        style={{ width: '300px', height: 'auto', marginBottom: '20px' }} // Adjusted size
      />
      <p>{product.description}</p>
      <p><strong>Price: ${product.price}</strong></p>
      <p><strong>Brand:</strong> {product.brand}</p>
      <p><strong>Rating:</strong> {product.rating} / 5</p>
      <p><strong>Stock:</strong> {product.stock > 0 ? 'In Stock' : 'Out of Stock'}</p>
      <p><strong>Category:</strong> {product.category}</p>
      
      {/* Display additional images in circular format */}
      {product.images && product.images.length > 0 && (
        <div>
          <h5>Additional Images:</h5>
          <div style={{ display: 'flex', gap: '10px' }}>
            {product.images.map((img, index) => (
              <img
                key={index}
                src={img}
                alt={`Additional view ${index + 1}`}
                style={{
                  width: '50px', // Adjust size as needed
                  height: '50px', // Adjust size as needed
                  borderRadius: '50%', // Makes the image circular
                  objectFit: 'cover', // Ensures the image covers the entire area
                }}
              />
            ))}
          </div>
        </div>
      )}

      <button
        onClick={handleBackToCategory}
        style={{
          backgroundColor: '#007bff', // Blue button
          color: 'white',
          border: 'none',
          padding: '10px 20px',
          borderRadius: '5px',
          cursor: 'pointer',
          marginTop: '20px',
        }}
      >
        Back to Category
      </button>
    </div>
  );
};

export default ProductDetails;
