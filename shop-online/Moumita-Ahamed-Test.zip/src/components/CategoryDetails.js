import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';

const CategoryDetails = () => {
  const { name } = useParams();
  const [products, setProducts] = useState([]);

  useEffect(() => {
    // Fetch products for the selected category
    fetch(`https://dummyjson.com/products/category/${name}`)
      .then((res) => res.json())
      .then((data) => {
        console.log(data.products); // Check product data
        setProducts(data.products);
      })
      .catch((err) => console.error('Error fetching products:', err));
  }, [name]);

  return (
    <div style={{ padding: '20px' }}>
      <h2>Category: {name}</h2>
      <div className="row" style={{ display: 'flex', justifyContent: 'center' }}>
        {products.map((product) => (
          <div className="col-md-4" key={product.id} style={{ marginBottom: '20px' }}>
            <div className="card" style={{ width: '14rem', textAlign: 'center', padding: '10px' }}>
              <img
                src={product.thumbnail}
                alt={product.title}
                style={{ width: '100%', height: '200px', objectFit: 'cover', marginBottom: '10px' }}
              />
              <div className="card-body">
                <p className="card-text" style={{ fontWeight: 'bold' }}>{product.title}</p>
                <Link to={`/product/${product.id}`}>
                  <button
                    type="button"
                    style={{
                      backgroundColor: '#007bff', // Blue button
                      color: 'white',
                      border: 'none',
                      padding: '10px 20px',
                      borderRadius: '5px',
                      cursor: 'pointer',
                    }}
                  >
                    View Details
                  </button>
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CategoryDetails;
